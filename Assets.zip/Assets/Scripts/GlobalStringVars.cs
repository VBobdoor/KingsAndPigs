using UnityEngine;

public class GlobalStringVars : MonoBehaviour
{
    public const string HORIZONTAL_AXIS = "Horizontal";
    public const string VERTICAL_AXIS = "Vertical";
    public const string Jump = "Jump";
    public const string Attack = "Fire1";
}
